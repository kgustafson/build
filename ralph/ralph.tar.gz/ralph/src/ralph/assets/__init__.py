default_app_config = 'ralph.assets.apps.AssetsConfig'
