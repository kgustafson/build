from ralph.apps import RalphAppConfig


class BackOfficeConfig(RalphAppConfig):
    name = 'ralph.back_office'
    verbose_name = 'Back Office'
